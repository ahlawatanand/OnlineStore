package utility;

   public class Constant {

      public static final String URL = "https://trello.com/";
      public static final String Username = "testuser_1";
      public static final String Password = "Test@123";
      public static final String Path_TestData = "C:/Users/Anand/workspace/OnlineStore/src/main/java/testData/";
      public static final String File_TestData = "TestData.xlsx";

   }